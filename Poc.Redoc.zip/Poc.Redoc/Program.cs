using Microsoft.OpenApi.Any;
using Microsoft.OpenApi.Interfaces;
using System.Reflection;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{

    c.SwaggerDoc("v1", new Microsoft.OpenApi.Models.OpenApiInfo()
    {
        Title = "Reneg Cobran�a",
        Description = @" 
**Teste** 2
# Introdu��o
- Detalhe 1
- Detalhe 2
## Tabela integra��o

| Id | Produto |
| -- | ----- |
| 1 | Cart�es | 
| 2 | IAXP | 

---

Fim
",
        Extensions = new Dictionary<string, IOpenApiExtension>()
        {
            {"x-logo", new OpenApiObject
            {
                { "url", new OpenApiString("/xp-inc-new.png") },
                { "altText", new OpenApiString("XP INC") },
            } }
        },
    });

    var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
    var path = Path.Combine(AppContext.BaseDirectory, xmlFile);
    c.IncludeXmlComments(path, includeControllerXmlComments: true);
    c.EnableAnnotations();
    
});


var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    //app.UseSwaggerUI();
    app.UseReDoc(c =>
    {
        c.DocumentTitle = "Documenta��o";
        c.RoutePrefix = "docs/api";
        c.SpecUrl = "/swagger/v1/swagger.json";
        

        c.HideDownloadButton();
        
    });
}

app.UseHttpsRedirection();

app.UseStaticFiles();
app.UseAuthorization();

app.MapControllers();

app.Run();
