﻿using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using System.ComponentModel;

namespace Poc.Redoc.Controllers
{
    [ApiController]
    [Route("api/v1/[controller]")]
    [Produces("application/json")]
    [Consumes("application/json")]
    [SwaggerTag("Essas rotas e contratos devem ser configuradas no produto. A plataforma de cobrança irá consumir essas apis exatamente nesses templates de rotas e contratos de request e response")]
    public class PlansController : ControllerBase
    {
        public PlansController()
        {

        }

        /// <summary>
        /// Retorna todos os planos disponíves
        /// </summary>
        /// <param name="brand">Qual é o tipo da conta do cliente (XP, XPbanco)</param>
        /// <param name="tradingAccount">Número da conta do cliente</param>
        /// <param name="contract">Número do contrato</param>
        /// <returns>Retorna as parcelas do cliente</returns>
        /// <remarks>
        /// 
        /// 
        ///     Brand:
        ///     
        ///         3 = XP
        ///         
        ///         348 = XPBank
        ///         
        ///     
        /// </remarks>
        [HttpGet("{brand}/{tradingAccount}/contract/{contract}", Name = "Obter planos")]
        [ProducesResponseType(typeof(IEnumerable<Installment>), StatusCodes.Status200OK)]
        public IActionResult GetPlans([FromRoute] Brand brand, [FromRoute] long tradingAccount, [FromRoute] string contract)
        {
            return Ok();
        }

        /// <summary>
        /// Envia para o produto o plano selecionado
        /// </summary>
        /// <param name="installment">objeto do plano selecionado</param>
        /// <returns>Retorna as parcelas do cliente</returns>
        [HttpPost("select", Name = "Selecionar um plano")]
        [ProducesResponseType(typeof(Installment), StatusCodes.Status200OK)]
        public IActionResult SetPlan([FromBody] Installment installment)
        {
            return Ok();
        }
    }

    public enum Brand
    {
        /// <summary>
        /// XP
        /// </summary>
        [Description("XP")]
        XP = 3,
        /// <summary>
        /// XPBank
        /// </summary>
        [Description("XPBank")]
        XpBank = 348
    }

    public class Installment
    {
        /// <summary>
        /// Identificador de correlação entre sistemas
        /// </summary>
        public Guid CorrelationId { get; set; }
        /// <summary>
        /// Valor da parcela
        /// </summary>
        public decimal InstallmentValue { get; set; }
        /// <summary>
        /// Número da parcela
        /// </summary>
        public int InstallmentNumber { get; set; }
        /// <summary>
        /// Data de vencimento da parcela
        /// </summary>
        public DateTime DueDate { get; set; }

    }
}
